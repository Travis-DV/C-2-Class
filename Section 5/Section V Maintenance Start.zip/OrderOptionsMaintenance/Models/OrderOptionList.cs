﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.Design.AxImporter;

namespace OrderOptionsMaintenance.Models
{
    public class OrderOptionList
    {
        private List<OrderOption> orderOptionList;

        //STEP 1 CREATE DELEGATE AND EVENT HERE

        public OrderOptionList() => orderOptionList = new();

        public int Count => orderOptionList.Count;

        public OrderOption this[int i]
        {
            get
            {
                //STEP 2 DEFINE get HERE
            }
            set
            {
                //STEP 2 DEFINE set HERE
            }
        }

        public void Add(OrderOption item)
        {
            orderOptionList.Add(item);
            if (Changed != null)
                Changed(this);
        }

        //STEP 3 CREATE Add() OVERLOAD HERE

        public void Remove(OrderOption order)
        {
            orderOptionList.Remove(order);
            if (Changed != null)
                Changed(this);
        }

        //STEP 4 CREATE + and - OVERLOADS HERE

    }
}
