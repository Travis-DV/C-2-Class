﻿namespace CustomerMaintenance
{

    public class CustomerList
    {

        private List<Customer> Customers;

        public CustomerList() => Customers = new();

        public delegate void ModHandler(CustomerList customers);
        public event ModHandler Modified = null!;

        public int Count => Customers.Count;

        public Customer this[int i] 
        {
            get => Customers[i];
            set 
            {
                Customers[i] = value;
                if (Modified != null) Modified(this);
            }
        }

        public void Append(Customer customer)
        {
            Customers.Add(customer);
            if (Modified != null) Modified(this);
        }

        public void Delete(Customer customer)
        {
            Customers.Remove(customer);
            if (Modified != null) Modified(this);
        }

        public void Populate() => Customers = CustomerDB.GetCustomers();

        public void SaveAll() => CustomerDB.SaveCustomers(Customers);

        public static CustomerList operator +(CustomerList Customers, Customer customer)
        {
            Customers.Append(customer);
            return Customers;
        }

        public static CustomerList operator -(CustomerList Customers, Customer customer)
        {
            Customers.Delete(customer);
            return Customers;
        }

        public static void Changed()
        {

        }

    }

    
}
