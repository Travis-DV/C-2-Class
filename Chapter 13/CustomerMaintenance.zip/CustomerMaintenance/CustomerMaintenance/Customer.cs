﻿namespace CustomerMaintenance
{
    public class Customer
    {
        public Customer() { }

        private string firstName = "";
        private string lastName = "";
        private string email = "";

        public Customer(string firstName, string lastName, string email) =>
            (this.FirstName, this.LastName, this.Email) = (firstName, lastName, email);

        public string FirstName
        {
            get => firstName;
            set
            {
                if (value.Length > 25) { 
                    throw new ArgumentException("Please input a first name that is less than 25 charictors");
                }
                firstName = value; 
            }
        }

        public string LastName
        {
            get => lastName;
            set
            {
                if (value.Length > 35) { 
                    throw new ArgumentException("Please input a last name that is less than 35 charictors");
                }
                lastName = value;
            }
        }

        public string Email
        {
            get => email;
            set
            {
                if (value.Length > 40) { 
                    throw new ArgumentException("Please input an Email that is less than 40 charictors"); 
                }
                email = value;
            }
        }

        public string GetDisplayText() => $"{FirstName} {LastName}, {Email}";
    }
}
